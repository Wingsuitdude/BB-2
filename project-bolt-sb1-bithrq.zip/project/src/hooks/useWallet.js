import { useState } from 'react';
import { useAccount, useConnect, useDisconnect } from 'wagmi';
import { useAuthStore } from '../stores/useAuthStore';
import { getProfile, createProfile } from '../lib/supabase';

export function useWallet() {
  const { address, isConnected } = useAccount();
  const { connect, connectors, isLoading: isConnecting, pendingConnector } = useConnect();
  const { disconnect } = useDisconnect();
  const { setProfile, setError, setLoading, clearProfile } = useAuthStore();

  const loadProfile = async (userAddress) => {
    try {
      setLoading(true);
      let profile = await getProfile(userAddress);
      
      if (!profile) {
        profile = await createProfile(userAddress);
      }

      if (profile) {
        setProfile(profile);
      } else {
        setError('Failed to load profile');
      }
    } catch (err) {
      console.error('Error loading profile:', err);
      setError('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const connectWallet = async (connector) => {
    try {
      await connect({ connector });
      if (address) {
        await loadProfile(address);
      }
    } catch (err) {
      console.error('Failed to connect wallet:', err);
      setError('Failed to connect wallet');
      clearProfile();
    }
  };

  const disconnectWallet = () => {
    disconnect();
    clearProfile();
  };

  return {
    account: address,
    isConnecting,
    connectWallet,
    disconnectWallet,
    isConnected,
    connectors,
    activeConnector: pendingConnector?.id
  };
}