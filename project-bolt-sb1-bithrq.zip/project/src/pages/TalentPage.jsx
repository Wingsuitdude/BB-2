import React, { useState, useEffect } from 'react';
import { TalentCard } from '../components/talent/TalentCard';
import { TalentFilters } from '../components/talent/TalentFilters';
import { getAllProfiles } from '../lib/supabase/profiles';

export function TalentPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [profiles, setProfiles] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadProfiles = async () => {
      try {
        const data = await getAllProfiles();
        setProfiles(data);
      } catch (error) {
        console.error('Error loading profiles:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadProfiles();
  }, []);

  const filteredProfiles = profiles.filter(profile => {
    const searchLower = searchTerm.toLowerCase();
    return (
      profile.username?.toLowerCase().includes(searchLower) ||
      profile.headline?.toLowerCase().includes(searchLower) ||
      profile.skills?.some(skill => skill.toLowerCase().includes(searchLower)) ||
      profile.location?.toLowerCase().includes(searchLower)
    );
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <h1 className="text-3xl font-bold text-white mb-8">Find Talent</h1>
      <TalentFilters searchTerm={searchTerm} onSearchChange={setSearchTerm} />
      <div className="space-y-6">
        {filteredProfiles.length > 0 ? (
          filteredProfiles.map((profile, index) => (
            <TalentCard key={profile.id} profile={profile} index={index} />
          ))
        ) : (
          <div className="text-center text-gray-400 py-12">
            <p>No profiles found matching your search criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}