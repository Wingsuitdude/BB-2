import React from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../common/Button';
import { ProjectCard } from './ProjectCard';

export function ProjectList({ projects, isOwner, isMember }) {
  return (
    <div className="space-y-6">
      {(isOwner || isMember) && (
        <div className="flex justify-end">
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            New Project
          </Button>
        </div>
      )}

      <div className="grid gap-6">
        {projects.map((project, index) => (
          <ProjectCard key={project.id} project={project} index={index} />
        ))}
      </div>
    </div>
  );
}