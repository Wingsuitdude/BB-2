import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { WalletOption } from './WalletOption';
import { Logo } from '../common/Logo';

export function WalletModal({ isOpen, onClose, onSelectWallet, isConnecting, activeConnector }) {
  if (!isOpen) return null;

  const wallets = [
    {
      id: 'metaMask',
      name: 'MetaMask',
      icon: "https://upload.wikimedia.org/wikipedia/commons/3/36/MetaMask_Fox.svg",
    },
    {
      id: 'coinbaseWallet',
      name: 'Coinbase Wallet',
      icon: "https://upload.wikimedia.org/wikipedia/commons/1/1a/Coinbase_Wallet_Logo.png",
      customIcon: <Logo size={24} className="mr-2" />,
    }
  ];

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
        onClick={onClose}
        aria-hidden="true"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: -20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: -20 }}
        className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[90%] max-w-md"
        role="dialog"
        aria-modal="true"
        aria-labelledby="wallet-modal-title"
      >
        <div className="bg-dark-100 rounded-lg border border-gray-800 p-6 shadow-xl">
          <div className="flex justify-between items-center mb-6">
            <h2 id="wallet-modal-title" className="text-xl font-semibold text-white">
              Connect Wallet
            </h2>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white transition-colors rounded-full hover:bg-dark-200"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4">
            {wallets.map((wallet) => (
              <WalletOption
                key={wallet.id}
                name={wallet.name}
                icon={wallet.icon}
                customIcon={wallet.customIcon}
                onClick={() => onSelectWallet(wallet.id)}
                disabled={isConnecting}
                isLoading={isConnecting && activeConnector === wallet.id}
                className="min-h-[56px]"
              />
            ))}
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-400">
              By connecting your wallet, you agree to our{' '}
              <button className="text-primary-400 hover:text-primary-300 underline">
                Terms of Service
              </button>{' '}
              and{' '}
              <button className="text-primary-400 hover:text-primary-300 underline">
                Privacy Policy
              </button>
            </p>
          </div>
        </div>
      </motion.div>
    </>
  );
}