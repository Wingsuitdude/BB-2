import React, { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Wallet, LogOut } from 'lucide-react';
import { Button } from '../common/Button';
import { WalletModal } from './WalletModal';
import { useWallet } from '../../hooks/useWallet';

export function WalletConnect() {
  const [isOpen, setIsOpen] = useState(false);
  const { connectWallet, disconnectWallet, isConnecting, connectors, account, activeConnector } = useWallet();

  const handleConnect = async (connectorId) => {
    try {
      const connector = connectors.find(c => c.id === connectorId);
      if (connector) {
        await connectWallet(connector);
        setIsOpen(false);
      }
    } catch (error) {
      console.error('Error connecting wallet:', error);
    }
  };

  if (account) {
    return (
      <Button 
        variant="outline" 
        onClick={disconnectWallet} 
        className="p-2"
        aria-label="Disconnect wallet"
      >
        <LogOut className="w-4 h-4" />
      </Button>
    );
  }

  return (
    <>
      <Button 
        onClick={() => setIsOpen(true)} 
        disabled={isConnecting}
        className="px-4 py-2 text-sm"
        aria-label="Connect wallet"
      >
        <Wallet className="w-4 h-4 mr-2" />
        {isConnecting ? 'Connecting...' : 'Connect Wallet'}
      </Button>

      <AnimatePresence>
        <WalletModal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          onSelectWallet={handleConnect}
          isConnecting={isConnecting}
          activeConnector={activeConnector}
        />
      </AnimatePresence>
    </>
  );
}