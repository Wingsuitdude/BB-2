import React from 'react';
import { motion } from 'framer-motion';
import { Coins, Users, Building2, Wallet2 } from 'lucide-react';

export function RewardStats({ stats }) {
  const statCards = [
    {
      title: "Verified Users",
      value: stats.verifiedUsers.toString(),
      icon: Users,
      change: null
    },
    {
      title: "ETH Pool",
      value: `${stats.ethPool} ETH`,
      icon: Wallet2,
      change: null
    },
    {
      title: "Active Bases",
      value: stats.totalBases.toString(),
      icon: Building2,
      change: null
    },
    {
      title: "BASES Holders",
      value: stats.basesHolders.toString(),
      icon: Coins,
      change: null
    }
  ];

  return (
    <div className="grid md:grid-cols-4 gap-6 mb-8">
      {statCards.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-dark-100 rounded-lg p-6 border border-gray-800"
        >
          <div className="flex justify-between items-start mb-4">
            <div className="bg-primary-500/10 p-2 rounded-lg">
              <stat.icon className="w-6 h-6 text-primary-400" />
            </div>
            {stat.change && (
              <span className="text-green-400 text-sm">{stat.change}</span>
            )}
          </div>
          <h3 className="text-gray-400 text-sm mb-1">{stat.title}</h3>
          <p className="text-2xl font-bold text-white">{stat.value}</p>
        </motion.div>
      ))}
    </div>
  );
}