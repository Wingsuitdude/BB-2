import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function RewardChart({ data }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="bg-dark-100 rounded-lg p-6 border border-gray-800"
    >
      <h2 className="text-xl font-semibold text-white mb-6">Growth Metrics</h2>
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2D3748" />
            <XAxis 
              dataKey="date" 
              stroke="#718096"
              tickFormatter={(value) => new Date(value).toLocaleDateString()}
            />
            <YAxis stroke="#718096" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1a202c',
                border: '1px solid #2d3748',
                borderRadius: '0.5rem'
              }}
            />
            <Line 
              type="monotone" 
              dataKey="users" 
              name="Verified Users"
              stroke="#0066ff"
              strokeWidth={2}
            />
            <Line 
              type="monotone" 
              dataKey="bases" 
              name="Active Bases"
              stroke="#00ff88"
              strokeWidth={2}
            />
            <Line 
              type="monotone" 
              dataKey="holders" 
              name="BASES Holders"
              stroke="#ff0066"
              strokeWidth={2}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}