import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { NotificationButtons } from './NotificationButtons';
import { ConnectButton } from './ConnectButton';
import { MessageButton } from '../messaging/MessageButton';
import { ImageUpload } from './ImageUpload';
import { ProfileStats } from './ProfileStats';
import { ProfileEdit } from './ProfileEdit';
import { Feed } from '../feed/Feed';
import { Button } from '../common/Button';
import { Settings } from 'lucide-react';

export function ProfileDashboard({ profile, isOwnProfile }) {
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('posts');

  if (!profile) return null;

  const tabs = [
    { id: 'posts', label: 'Posts' },
    { id: 'about', label: 'About' },
    { id: 'experience', label: 'Experience' },
    { id: 'education', label: 'Education' }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4">
      {/* Banner */}
      <div className="relative h-48 sm:h-64 rounded-xl overflow-hidden bg-gradient-to-r from-primary-600/20 to-primary-800/20 border border-gray-800">
        {profile?.banner_url ? (
          <img
            src={profile.banner_url}
            alt="Profile Banner"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-r from-primary-600/20 to-primary-800/20" />
        )}
        {isOwnProfile && (
          <div className="absolute top-4 right-4">
            <ImageUpload type="banners" />
          </div>
        )}
      </div>

      {/* Profile Header */}
      <div className="relative -mt-16 px-4 sm:px-8">
        <div className="flex flex-col items-center sm:flex-row sm:items-end space-y-4 sm:space-y-0 sm:space-x-6">
          {/* Avatar */}
          <div className="relative">
            <div className="w-32 h-32 rounded-full border-4 border-dark-100 overflow-hidden bg-dark-200 shadow-xl">
              {profile?.avatar_url ? (
                <img
                  src={profile.avatar_url}
                  alt={profile.username}
                  className="w-full h-full object-cover"
                />
              ) : (
                <img
                  src={`https://api.dicebear.com/7.x/shapes/svg?seed=${profile?.address}`}
                  alt={profile?.username}
                  className="w-full h-full object-cover"
                />
              )}
            </div>
            {isOwnProfile && (
              <div className="absolute bottom-0 right-0">
                <ImageUpload type="avatars" />
              </div>
            )}
          </div>

          {/* Profile Info */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-white">{profile.username}</h1>
                <p className="text-gray-400 mt-1">{profile.headline || 'No headline set'}</p>
              </div>
              {isOwnProfile ? (
                <div className="flex items-center space-x-3">
                  <NotificationButtons profileId={profile.id} />
                  <Button variant="secondary" onClick={() => setIsEditing(true)}>
                    <Settings className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <ConnectButton profileId={profile.id} />
                  <MessageButton
                    recipientId={profile.id}
                    recipientName={profile.username}
                  />
                </div>
              )}
            </div>
            <ProfileStats profile={profile} />
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-8 border-b border-gray-800 overflow-x-auto">
          <div className="flex space-x-8 whitespace-nowrap">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`pb-4 px-2 text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? 'text-primary-400 border-b-2 border-primary-400'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="mt-6">
          {activeTab === 'posts' && (
            <Feed userId={profile.id} showCreatePost={isOwnProfile} />
          )}

          {/* Other tab content remains the same */}
        </div>
      </div>

      {/* Edit Profile Modal */}
      {isEditing && (
        <ProfileEdit onClose={() => setIsEditing(false)} />
      )}
    </div>
  );
}