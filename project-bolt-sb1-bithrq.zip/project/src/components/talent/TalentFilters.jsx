import React from 'react';
import { Search, Filter } from 'lucide-react';
import { Button } from '../common/Button';

export function TalentFilters({ searchTerm, onSearchChange }) {
  return (
    <div className="flex gap-4 mb-8">
      <div className="flex-1 relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
        <input
          type="text"
          placeholder="Search by skill, location, or expertise..."
          className="w-full bg-dark-100 border border-gray-800 rounded-lg py-2 px-10 text-gray-300 focus:outline-none focus:border-primary-500"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
        />
      </div>
      <Button variant="secondary">
        <Filter className="w-4 h-4 mr-2" />
        Filters
      </Button>
    </div>
  );
}